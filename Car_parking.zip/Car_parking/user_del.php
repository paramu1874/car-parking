<?php
	include "config.php";
	$sql="delete from user where ID='{$_POST["id"]}'";
	if($con->query($sql))
	{
		echo "Data Deleted.";
	}

?>
