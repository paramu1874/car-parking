<?php 
	session_start();
	include "config.php";
	$sql="insert into book_slot(pid,bdate,slno,time,uid) values ";
	$rows=Array();
	$date=$_POST["bdate"];
	for($i=0;$i<count($_POST["slno"]);$i++)
	{
		$rows[]="('{$_POST["pid"]}','{$date}','{$_POST["slno"][$i]}','{$_POST["time"][$i]}','{$_SESSION["ID"]}')";
	}
	$sql.=implode(",",$rows);
	if($con->query($sql))
	{
		echo "Sloat Booked Succssfully";
	}
	else
	{
		echo "Sloat Booked Failed";
	}
?>

