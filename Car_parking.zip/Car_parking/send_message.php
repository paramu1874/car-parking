<?php
session_start();
include"config.php";
if(!isset($_SESSION["ID"]))
{
	echo "<script>window.open('index.php','_self')</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<?php include"head.php";?>
	<link rel="stylesheet" type="text/css" href="jqueryui/jquery-ui.css">
</head>
<body>  
 <?php include"user_navbar.php";?>
<div class="container">
	<div class="row">
		<div class="col-md-12 ">
			<h4><i class='fa fa-envelope'></i> Send Feedback</h4><hr>
			<form method='post' action='<?php echo $_SERVER["REQUEST_URI"];?>'>
				<div class='col-md-offset-4 col-md-4'>
					<div class='form-group'>
						<label class='text-primary'>Feedback Here</label>
						<textarea class='form-control' name='msg' required placeholder='Text Here...'></textarea>
					</div>
					<div class='form-group'>
						<input type='submit' name='submit' value='Send Feedback' class='btn btn-success'>
					</div>
					<?php 
						if(isset($_POST["submit"]))
						{
							$msg=mysqli_real_escape_string($con,$_POST["msg"]);
							$uid=$_SESSION["ID"];
							$sql="insert into message (uid,mdate,msg,type) values('{$uid}',NOW(),'{$msg}',0)";
							if($con->query($sql))
							{
									echo "<br><div class='alert alert-success'>Feedback Send Successfully</div>";
							}
						}
					?>
				</div>
			</form>
			
		</div>
	</div>
</div>
<?php include "footer.php";?>
<script src="jqueryui/jquery-ui.min.js"></script>
</body>
</html>	