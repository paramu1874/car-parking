-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2022 at 04:49 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `car_msn`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `AID` int(11) NOT NULL,
  `ANAME` varchar(150) NOT NULL,
  `APASS` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`AID`, `ANAME`, `APASS`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `book_slot`
--

CREATE TABLE `book_slot` (
  `bid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `bdate` date NOT NULL,
  `slno` int(11) NOT NULL,
  `time` int(11) NOT NULL DEFAULT 0,
  `uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_slot`
--

INSERT INTO `book_slot` (`bid`, `pid`, `bdate`, `slno`, `time`, `uid`) VALUES
(1, 4, '2022-04-06', 1, 1, 4),
(2, 4, '2022-04-06', 1, 15, 4),
(5, 3, '2022-04-08', 3, 11, 4),
(6, 3, '2022-04-08', 3, 14, 4),
(7, 3, '2022-04-08', 6, 11, 4),
(8, 3, '2022-04-08', 6, 15, 4),
(9, 3, '2022-04-08', 3, 13, 4),
(12, 5, '2022-04-11', 8, 19, 5),
(13, 5, '2022-04-11', 8, 23, 5),
(14, 5, '2022-04-11', 7, 14, 6),
(15, 5, '2022-04-11', 7, 19, 6),
(16, 3, '2022-04-29', 2, 17, 4),
(17, 3, '2022-04-29', 2, 20, 4);

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `mid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `mdate` varchar(45) NOT NULL DEFAULT '',
  `msg` text DEFAULT NULL,
  `type` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`mid`, `uid`, `mdate`, `msg`, `type`) VALUES
(1, 4, '2022-04-05 19:58:13', 'hello', '0');

-- --------------------------------------------------------

--
-- Table structure for table `parking_area`
--

CREATE TABLE `parking_area` (
  `PID` int(11) NOT NULL,
  `PAREA` varchar(150) NOT NULL,
  `NSLOT` int(11) NOT NULL,
  `CARS` varchar(150) NOT NULL,
  `PIMG` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parking_area`
--

INSERT INTO `parking_area` (`PID`, `PAREA`, `NSLOT`, `CARS`, `PIMG`) VALUES
(3, 'AR Parking', 15, 'Ignis', 'park/2.jpg'),
(5, 'MSN', 8, 'Baleno', 'park/123.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(150) NOT NULL,
  `PASS` varchar(150) NOT NULL,
  `UMAIL` varchar(150) NOT NULL,
  `PNO` varchar(150) NOT NULL,
  `PLACE` varchar(150) NOT NULL,
  `UIMG` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `NAME`, `PASS`, `UMAIL`, `PNO`, `PLACE`, `UIMG`) VALUES
(4, 'parameshwari', '1234', 'para@gmail.com', '', '', ''),
(5, 'tom', '1234', 'tom@gmail.com', '', '', ''),
(6, 'Vanitha', '1234', 'vai@gmail.com', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`AID`);

--
-- Indexes for table `book_slot`
--
ALTER TABLE `book_slot`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `parking_area`
--
ALTER TABLE `parking_area`
  ADD PRIMARY KEY (`PID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `AID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `book_slot`
--
ALTER TABLE `book_slot`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `mid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `parking_area`
--
ALTER TABLE `parking_area`
  MODIFY `PID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
