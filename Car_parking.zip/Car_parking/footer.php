<br style="cllear:both;"><br><br>
<div class="col-md-12" style="margin-top:50px;">
 <p class="text-center">Copyright &copy; <?php echo date("Y"); ?> Online Car Parking Reservation System</p>
</div>
<script src="js/jquery.js"></script>
<script src="js/1bootstrap.min.js"></script>

 	<script>
$(".alert").fadeTo(1000, 1000).slideUp(2000, function(){
    $(".alert").fadeOut(3000);
});
	
</script>