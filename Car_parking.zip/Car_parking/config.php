<?php
	$con=new mysqli("localhost","root","","car_msn");
	if(!$con)
	{
		echo"Database is  Not Connected";
	}

?>