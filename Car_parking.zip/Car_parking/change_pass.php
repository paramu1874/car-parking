<?php
session_start();
include"config.php";
if(!isset($_SESSION["ID"]))
{
	echo "<script>window.open('index.php','_self')</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<?php include"head.php";?>
</head>
<body>  
 <?php include"user_navbar.php";?>
<div class="container">
	<div class="row">
		
		<div class="col-md-12 ">

				<h3 class="page-header">Change Password</h3>
				<div class="col-md-12 sha">
					<div class="col-md-offset-3 col-md-6">
						<?php 
							if(isset($_POST["submit"]))
							{
								$sql="select * from user where PASS='{$_POST["opass"]}' and ID='{$_SESSION["ID"]}'";
								$result=$con->query($sql);
									if($result->num_rows>0)
									{
										if($_POST["npass"]==$_POST["cpass"])
										{
											$sql="UPDATE user SET  PASS='{$_POST["npass"]}' where  ID='{$_SESSION["ID"]}'";
											$con->query($sql);
											echo"<div class='alert alert-success'>password Changed</div>";
										}
										else
										{
											echo"<div class='alert alert-warning'>password Mismatch</div>";
										}
									}
									else
									{
										echo"<div class='alert alert-danger'>Invalid password</div>";
									}
							}
						?>
						<form action="<?php echo $_SERVER["PHP_SELF"];?>" role="form" method="post" >
							 <div class="form-group">
								 <label > Old Password : </label>
								 <input type="text"  name="opass"  required  class="form-control" placeholder="Old Password">
							</div>
							<div class="form-group">
								 <label > New Password : </label>
								 <input type="text"  name="npass"  required class="form-control" placeholder="New Password">
							</div>
							<div class="form-group">
								 <label > Confirm  Password : </label>
								 <input type="text"  name="cpass"  required class="form-control" placeholder="Confirm  Password">
							</div>
							<div class="form-group">
								<button type="submit" class="btn btn-success" id="submit" name="submit"> Save Details</button>
								<button type="reset" class="btn btn-danger" id="clear" name="clear"> Clear Details</button>
							</div>
						</form>
					
					</div>
				</div>
		</div>
	</div>
</div>
<?php include "footer.php";?>
</body>
</html>	