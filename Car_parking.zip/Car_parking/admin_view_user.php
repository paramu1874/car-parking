<?php
session_start();
include"config.php";
if(!isset($_SESSION["AID"]))
{
	echo "<script>window.open('index.php','_self')</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<?php include"head.php";?>
</head>
<body>  
 
<div class="container-fluid">
	<div class="row">
	<?php include"navbar.php";?>
		<div class="col-md-3 box">
			<?php include "sidebar.php";?>
		</div>
		<div class="col-md-9 mbox">
			
		
			<div class="col-md-12 content">
				<h3 class="page-header">View Users</h3>
				<p id="out"></p>
				<table class="table table-striped table-bordered">
			   <thead>
				   <tr>
					   <th>S.no</th>
					   <th>Name</th>
					   <th>Mail</th>
					   <th>Delete</th>
				   </tr>
			   </thead>
			   <tbody>
			   <?php 
					$sql= "select * from user";
					$res=$con->query($sql);
					if($res->num_rows>0)
					{
						$i=0;
						while($row=$res->fetch_assoc())
						{
							$i++;
							echo'
								<tr>
								   <td>'.$i.'</td>
								   <td>'.$row["NAME"].'</td>
								   <td>'.$row["UMAIL"].'</td>
								  
								   <td><a  href="#" dataId="'.$row['ID'].'" class="delData btn btn-xs btn-danger">Delete</a></td>
								</tr>
							';
						}
					}
			   
			   ?>
			
			   </tbody>
		 </table>
			</div>
			<?php include "footer.php";?>
		</div>
	</div>
</div>
<script>
$(document).ready(function(){
	
	$(".delData").click(function(e){
		e.preventDefault();
		var did=$(this).attr("dataId");
		var row=$(this);
		$.ajax({
			type:'POST',
			url:'user_del.php',
			data:{id:did},
			beforeSend:function(){
				$("#out").html("Deleting..");
			},
			success:function(data){
				$("#out").html("<div class='alert alert-success' >"+data+"</div>");
				row.closest("tr").hide();
			}
		});
	});
});
</script>
</body>
</html>	