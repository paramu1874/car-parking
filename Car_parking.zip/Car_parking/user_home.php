<?php
session_start();
include"config.php";
if(!isset($_SESSION["ID"]))
{
	echo "<script>window.open('index.php','_self')</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<?php include"head.php";?>
</head>
<body>  
 <?php include"user_navbar.php";?>
<div class="container">
	<div class="row">
		
		<div class="col-md-12 ">

				<h3 class="page-header">Welcome <?php echo $_SESSION["NAME"];?></h3>
				<div class="col-md-12 sha">
				<div class="col-md-4 " style="margin-top:50px;">
					<a href="view_area.php"><div class="progress blue">
						<span class="progress-left">
							<span class="progress-bar"></span>
						</span>
						<span class="progress-right">
							<span class="progress-bar"></span>
						</span>
						<div class="progress-value">Parking </div>
					</div></a>
				</div>
				<div class="col-md-4" style="margin-top:50px;">
					<a href="view_booking.php"><div class="progress yellow">
						<span class="progress-left">
							<span class="progress-bar"></span>
						</span>
						<span class="progress-right">
							<span class="progress-bar"></span>
						</span>
						<div class="progress-value">Booking</div>
					</div></a>
				</div>
				<div class="col-md-4" style="margin-top:50px;">
					<a href="send_message.php"><div class="progress green">
						<span class="progress-left">
							<span class="progress-bar"></span>
						</span>
						<span class="progress-right">
							<span class="progress-bar"></span>
						</span>
						<div class="progress-value">Message</div>
					</div></a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include "footer.php";?>
</body>
</html>	