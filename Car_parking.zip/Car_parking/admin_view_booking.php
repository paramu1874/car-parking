<?php
session_start();
include"config.php";
if(!isset($_SESSION["AID"]))
{
	echo "<script>window.open('index.php','_self')</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<?php include"head.php";?>
	<link rel="stylesheet" type="text/css" href="jqueryui/jquery-ui.css">
</head>
<body>  
 
<div class="container-fluid">
	<div class="row">
	<?php include"navbar.php";?>
		<div class="col-md-3 box">
			<?php include "sidebar.php";?>
		</div>
		<div class="col-md-9 mbox">
			
			<div class='col-md-12'>
			<div class="col-md-4">
				<h4><i class='fa fa-list'></i> View Booking Details</h4><hr>
				<form method='post' action='<?php echo $_SERVER["REQUEST_URI"];?>' autocomplete='off'>
					<div class='form-group'>
						<label class='text-primary'>Select Parking Area</label>
						<select class='form-control input-sm' name='pid' required>
							<option value=''>Select</option>
							<?php
								$sql="SELECT * FROM parking_area ";
								$res=$con->query($sql);
								if($res->num_rows>0)
								{
									while($row=$res->fetch_assoc())
									{
										echo "<option value='{$row["PID"]}'>{$row["PAREA"]}</option>";
									}
								}
							?>
						</select>
					</div>
					<div class='form-group'>
						<label class='text-primary'>From Date</label>
						<input type='text' class='form-control input-sm bdate' name='fdate'>
					</div>
					<div class='form-group'>
						<label class='text-primary'>To Date</label>
						<input type='text' class='form-control input-sm bdate' name='tdate'>
					</div>
					<div class='form-group'>
						<input type='submit' name='submit' value='View' class='btn btn-success btn-sm'>
					</div>
				</form>
			</div>
			</div>
			
			<div class="col-md-12 content">
				<h4 class="page-header"><i class='fa fa-car'></i> Booking Details</h4>
				<?php
				if(isset($_POST["submit"]))
				{
					?>
				<p id="out"></p>
				<table class="table table-striped table-bordered">
			   <thead>
				   <tr>
					   <th>S.no</th>
					   <th>Parking Name</th>
					   <th>Booking Date</th>
					   <th>Slot No</th>
					   <th>User Name</th>
					   <th>View</th>
				   </tr>
			   </thead>
			   <tbody>
			   <?php 
				
					$sql= "SELECT * FROM parking_area p inner join book_slot b on p.PID=b.pid inner join `user` u on b.uid=u.ID where p.PID={$_POST["pid"]} and b.bdate between '{$_POST["fdate"]}' and '{$_POST["tdate"]}' group by b.slno,b.uid,b.bdate,b.pid";
					$res=$con->query($sql);
					if($res->num_rows>0)
					{
						$i=0;
						while($row=$res->fetch_assoc())
						{
							$i++;
							echo'
								<tr>
								   <td>'.$i.'</td>
								   <td>'.$row["PAREA"].'</td>
								   <td>'.$row["bdate"].'</td>
								   <td>'.$row["slno"].'</td>
								   <td>'.$row["NAME"].'</td>
								  
								   <td>';
								   echo "<a  href='admin_views_booking.php?bid={$row["bid"]}&bdate={$row["bdate"]}&bname={$row["PAREA"]}&slno={$row["slno"]}&uid={$row["uid"]}' class='btn btn-xs btn-success'>View</a></td>
								</tr>
							";
						}
					}
			   ?>
			
			   </tbody>
		 </table>
		 <?php 
			}
		 ?>
			</div>
			<?php include "footer.php";?>
			<script src="jqueryui/jquery-ui.min.js"></script>
		</div>
	</div>
</div>
<script>
$(document).ready(function(){
	$(".bdate").datepicker({
		  dateFormat:"yy-mm-dd"
	});
});
</script>
</body>
</html>	