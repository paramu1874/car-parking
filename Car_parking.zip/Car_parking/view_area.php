<?php
session_start();
include"config.php";
if(!isset($_SESSION["ID"]))
{
	echo "<script>window.open('index.php','_self')</script>";
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
	<?php include"head.php";?>
	<style>
		.imgs{
			height:200px;
			width:250px;
		
		}
	</style>
</head>
<body>  
 <?php include"user_navbar.php";?>
<div class="container">
	<div class="row">
		
		<div class="col-md-12 ">

				<h3 class="page-header">View Parking Area</h3>
				<div class="col-md-12 sha">
					
						<?php
							$sql="SELECT * FROM parking_area";
							$res=$con->query($sql);

							if($res->num_rows>0)
							{
								while($row=$res->fetch_assoc())
								{
						?>
									<a href="booking.php?id=<?php echo $row["PID"];?>&pname=<?php echo $row["PAREA"];?>&img=<?php echo $row["PIMG"];?>"><div class="col-md-3 pbox">
										<center><img src="<?php echo $row["PIMG"];?>" class="imgs img-thumbnail"></center><hr>
										<h3 class="text-center" style="color:white;">   <?php echo $row["PAREA"];?></h3>
									</div></a>
						<?php
								}
							}
						?>
					
				</div>
		</div>
	</div>
</div>
<?php include "footer.php";?>
</body>
</html>	