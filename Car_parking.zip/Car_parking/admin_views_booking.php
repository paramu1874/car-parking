<?php
session_start();
include"config.php";
if(!isset($_SESSION["AID"]))
{
	echo "<script>window.open('index.php','_self')</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<?php include"head.php";?>
	<link rel="stylesheet" type="text/css" href="jqueryui/jquery-ui.css">
	<style>
		.slot_box{
			background:black;
			padding:10px;
			color:white;
			border-radius:4px;
			margin:50px;
			border:1px solid white;
			cursor:pointer;
			font-weight:bold;
			text-align:center;
		}
		
		.success{
			background:green;
		}
		
		.booked{
			background:red;
			color:white;
		}
		.book{
			background:green;
			color:white;
		}
		.slots{
			width:45px;
			height:25px;
			box-sizing:border-box;
			padding:3px 3px 3px 5px;
			float:left;
			margin-left:10px;
			margin-top:10px;
			box-shadow:1px 1px 5px 1px #ebebeb;
			cursor:pointer;
		}
		.sname{
			text-align:center;
			font-size:15px;
			font-weight:bold;
			width:100%;
			display:block;
			margin-top:20px;
			color:blue;
		}
		.sbox{
			width:100%;
			display:block;
			float:left;
			box-shadow:1px 1px 5px 1px #d4d4d4;
			margin-top:20px;
			padding-left:5px;
			padding-right:5px;
			padding-bottom:20px;
			border-radius:10px;
		}
	</style>
</head>
<body>  
 
<div class="container-fluid">
	<div class="row">
	<?php include"navbar.php";?>
		<div class="col-md-3 box">
			<?php include "sidebar.php";?>
		</div>
		<div class="col-md-9 mbox">
			
			<div class='col-md-12'>
					<h4><i class='fa fa-list'></i> View Booking Details</h4><hr>
					<?php
					$date=date("d-m-Y",strtotime($_GET["bdate"]));
					$sql="SELECT * FROM book_slot inner join parking_area on book_slot.pid=parking_area.pid  where uid={$_GET["uid"]} and slno={$_GET["slno"]} and bdate='{$_GET["bdate"]}'";
					$res=$con->query($sql);
					$time=Array();
					if($res->num_rows>0)
					{
						while($row=$res->fetch_assoc())
						{
							$time[]=$row["time"];
						}
					}
					// echo "<pre>";
					// print_r($slots);
					// echo "</pre>";
					echo'<div class="col-md-12" id="out">';
					echo "<div class='col-md-4'>
						<table class='table table-bordered' style='margin-top:25px;'>
							<tr>
								<th>Booking Date</th>
								<td>{$date}</td>
							</tr>
							<tr>
								<th>Parking Area</th>
								<td>{$_GET["bname"]}</td>
							</tr>
							<tr>
								<th>No of Hours</th>
								<td>".count($time)."</td>
							</tr>
						</table>
					
					</div>";
					$sql="SELECT NSLOT FROM book_slot inner join parking_area on book_slot.pid=parking_area.pid  where bid={$_GET["bid"]}";
					$res=$con->query($sql);
					if($res->num_rows>0)
					{
						
						$ro=$res->fetch_assoc();
						$slot=$ro["NSLOT"];
						echo "<div class='row'>";
						for($i=1;$i<=1;$i++)
						{
							echo "<div class='col-md-offset-1 col-md-3'>";
							echo "<div class='sbox'>
							<span class='sname'>Slot {$i} : <i class='fa fa-clock-o'></i></span><hr>";
								for($h=1;$h<=24;$h++)
								{
									$cls="";
									$state=0;
									if(in_array($h,$time))
									{
										$cls="booked";
										$state=2;
									}
									echo "<div class='slots {$cls}' slno='{$i}' hrs='{$h}' state='{$state}'>
										".sprintf('%02d', $h).".00
									</div>
									";
								}
							echo "</div></div>";
							?>
							
											
							<?php
						}
						echo "</div>";
					}
			?>
				</div>
				<?php include "footer.php";?>
				<script src="jqueryui/jquery-ui.min.js"></script>
			
		</div>
	</div>
</div>
<script>
$(document).ready(function(){
	$(".bdate").datepicker({
		  dateFormat:"yy-mm-dd"
	});
});
</script>
</body>
</html>	