<?php
session_start();
include"config.php";
if(!isset($_SESSION["ID"]))
{
	echo "<script>window.open('index.php','_self')</script>";
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
	<?php include"head.php";?>
	<link rel="stylesheet" type="text/css" href="jqueryui/jquery-ui.css">
	<style>
		.slot_box{
			background:black;
			padding:10px;
			color:white;
			border-radius:4px;
			margin:50px;
			border:1px solid white;
			cursor:pointer;
			font-weight:bold;
			text-align:center;
		}
		
		.success{
			background:green;
		}
		
		.booked{
			background:red;
		}
		.book{
			background:green;
		}
		.slots{
			width:25px;
			height:25px;
			box-sizing:border-box;
			padding:3px;
			float:left;
			margin-left:10px;
			margin-top:10px;
			box-shadow:1px 1px 5px 1px #ebebeb;
			cursor:pointer;
		}
		.sname{
			text-align:center;
			font-size:20px;
			font-weight:bold;
			width:100%;
			display:block;
			margin-top:20px;
		}
		.sbox{
			width:100%;
			display:block;
			float:left;
			box-shadow:1px 1px 5px 1px #d4d4d4;
			margin-top:20px;
			padding-left:5px;
			padding-right:5px;
			padding-bottom:20px;
		}
	</style>
</head>
<body>  
 <?php include"user_navbar.php";?>
<div class="container">
	<div class="row">
		
		<div class="col-md-12 ">

				<h3 class="page-header">Booking Area</h3>
				<div class="col-md-12 sha">
					<h3 >Book A Slot</h3><hr>
					<form action="<?php echo $_SERVER["REQUEST_URI"];?>" method="post" autocomplete='off'>
						<div class="form-group col-md-4">
							<label > Date </label>
							<input type="text" class="form-control bdate" name="bdate"  required>
						</div>
						<div class="form-group col-md-12">
							<button class="btn btn-success" type="submit" id="btn" name="submit">View Slot</button>
							
						</div>
					</form>
					<br style="clear:both;"><br>
					<form>
					
					<?php
						if(isset($_POST["submit"]))
						{
							$sql="SELECT slno FROM book_slot where pid='{$_GET["id"]}' and bdate='{$_POST["bdate"]}' and time='{$_POST["time"]}'";
							$res=$con->query($sql);
							$slots=Array();
							if($res->num_rows>0)
							{
								while($row=$res->fetch_assoc())
								{
									$slots[]=$row["slno"];
								}
							}
							// echo "<input type='hidden' value='{$_POST["bdate"]}' id='bdate'>";
							// echo "<input type='hidden' value='{$_POST["time"]}' id='time'>";
							// echo "<input type='hidden' value='{$_POST["hrs"]}' id='hrs'>";
							echo'<div class="col-md-12" id="out">';
							$sql="select * from parking_area where PID='{$_GET["id"]}'";
							$res=$con->query($sql);
							if($res->num_rows>0)
							{
								
								$ro=$res->fetch_assoc();
								$slot=$ro["NSLOT"];
								echo "<div class='row'>";
								for($i=1;$i<=$slot;$i++)
								{
									echo "<div class='col-md-3'>";
									echo "<div class='sbox'><span class='sname'>Slot {$i}</span>";
										for($h=1;$h<=24;$h++)
										{
											
											echo "<div class='slots'>
												{$h}
											</div>
											";
										}
									echo "</div></div>";
									?>
									
													
									<?php
								}
								echo "</div>";
							}
							else{
								echo' No slots Here in this Parking Area..';
							}
							
							
							echo'</div>
							<br style="clear:both;"><br>
							<button class="btn btn-success pull-right" type="button" id="save" name="submit" >Book Slot</button>
						</form>
							
							';
						}
					
					?>
					
					
					
				</div>
		</div>
	</div>
</div>
<?php include "footer.php";?>
<script src="jqueryui/jquery-ui.min.js"></script>
<script>
	var sno=0;
	$(document).ready(function(){
		$(".bdate").datepicker({
		  minDate: 0,
		  onSelect: function(date) {
			$(".bdate").datepicker('option', 'minDate', date);
		  },
		  dateFormat:"yy-mm-dd"
		});
		$("#bdate").datepicker({
			
		});
		
		$(".slot_box").click(function(){
			if($(this).hasClass("booked"))
			{
				return;
			}
			var cls=$(this);
			var val=$(this).attr("val");
			sno=val;
			$(".slot_box").each(function(){				
				$(this).removeClass("book");
			});
			$(this).toggleClass("book");
			
		});
		$("#save").click(function(){
			if(sno==0)
			{
				alert("Select Slot ");
				return;
			}
			var pid=<?php echo $_GET["id"];?>;
			var bdate=$("#bdate").val();
			var time=$("#time").val();
			var hrs=$("#hrs").val();
			$.ajax({
				url:"save_slot.php",
				type:"post",
				data:{pid:pid,bdate:bdate,time:time,hrs:hrs,slno:sno},
				success:function(res){
					alert(res);
					location.reload();
				}
			});
		});
	});


	
	

</script>
</body>
</html>	