<?php
session_start();
include"config.php";
if(!isset($_SESSION["AID"]))
{
	echo "<script>window.open('index.php','_self')</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<?php include"head.php";?>
</head>
<body>  
 
<div class="container-fluid">
	<div class="row">
		<div class="col-md-3 box">
			<?php include "sidebar.php";?>
		</div>
		<div class="col-md-9 mbox">
			<?php include"navbar.php";?>
			<div class="col-md-5 content">
				<h3 class="page-header">Add Parking Area</h3>
					<?php
						if(isset($_POST["submit"]))
							{
								$parea=$con->escape_string($_POST["parea"]);
								$nslot=$con->escape_string($_POST["nslot"]);
								$cars=$con->escape_string($_POST["cars"]);
								
								$target="park/";
								
								$target_File=$target.basename($_FILES["img"]["name"]);
								
								if(move_uploaded_file($_FILES['img']['tmp_name'],$target_File))
								{
									$sql="INSERT INTO parking_area(PAREA, NSLOT,PIMG,CARS) VALUES('{$parea}','{$nslot}','{$target_File}','{$cars}')";
									$con->query($sql);
									echo "<div class='alert alert-success'>Insert Successfully</div>";
								}
								else{
									echo "<div class='alert alert-danger'>Insert Failed</div>";
								}
							

							}
					?>
				<form  enctype="multipart/form-data" role="form"  method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
					<div class="form-group">
						<label > Area Name</label>
						<input type="text" class="form-control" name="parea" required>
					</div>
					<div class="form-group">
						<label > Number of Slots</label>
						<input type="text" class="form-control" name="nslot" required>
					</div>
					<div class="form-group">
						<label > Cars Type for Slots</label>
						<select class="form-control" name="cars" required>
							<option value="Baleno">Baleno</option> 
							<option value="Celerio">Celerio</option>
							<option value="Ciaz">Ciaz</option>
							<option value="Dzire">Dzire</option>
							<option value="Eeco">Eeco</option>
							<option value="Ertiga">Ertiga</option>
							<option value="Ignis">Ignis</option>
							<option value="S-Cross">S-Cross</option>
							<option value="S-Presso">S-Presso</option>
							<option value="Vitara Brezza">Vitara Brezza</option>
							<option value="Swift">Swift</option>
							<option value="Wagon">Wagon</option>
							<option value="XL6">XL6</option>
							<option value="XL5">XL5</option>
						
						</select>
					</div>
					<div class="form-group">
							<label > Image : </label>
							<input type="file"  name="img" required>
						</div>
					
					
					<div class="form-group">
						<button class="btn btn-success" type="submit" name="submit">Add Details</button>
						
					</div>
				</form>
			</div>
			<div class="col-md-7 content">
				<h3 class="page-header">View Parking Area</h3>
				<p id="out"></p>
				<table class="table table-hover table-bordered">
			   <thead>
				   <tr>
					   <th>S.no</th>
					   <th>Area</th>
					   <th>Slot</th>
					   <th>Car Type</th>
					   <th>Image</th>
					   <th>Delete</th>
				   </tr>
			   </thead>
			   <tbody>
			   <?php 
					$sql= "select * from parking_area";
					$res=$con->query($sql);
					if($res->num_rows>0)
					{
						$i=0;
						while($row=$res->fetch_assoc())
						{
							$i++;
							echo'
								<tr>
								   <td>'.$i.'</td>
								   <td>'.$row["PAREA"].'</td>
								   <td>'.$row["NSLOT"].'</td>
								   <td>'.$row["CARS"].'</td>
								   <td><img src="'.$row["PIMG"].'" height="50" width="50"></td>
								  
								   <td><a  href="#" dataId="'.$row['PID'].'" class="delData btn btn-xs btn-danger">Delete</a></td>
								</tr>
							';
						}
					}
			   
			   ?>
			
			   </tbody>
		 </table>
			</div>
			<?php include "footer.php";?>
		</div>
	</div>
</div>
<script>
$(document).ready(function(){
	
	$(".delData").click(function(e){
		e.preventDefault();
		var did=$(this).attr("dataId");
		var row=$(this);
		$.ajax({
			type:'POST',
			url:'parking_del.php',
			data:{id:did},
			beforeSend:function(){
				$("#out").html("Deleting..");
			},
			success:function(data){
				$("#out").html("<div class='alert alert-success' >"+data+"</div>");
				row.closest("tr").hide();
			}
		});
	});
});
</script>
</body>
</html>	