<?php
session_start();
include"config.php";
if(!isset($_SESSION["ID"]))
{
	echo "<script>window.open('index.php','_self')</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<?php include"head.php";?>
	<link rel="stylesheet" type="text/css" href="jqueryui/jquery-ui.css">
</head>
<body>  
 <?php include"user_navbar.php";?>
<div class="container">
	<div class="row">
		<div class="col-md-12 ">
			<h4><i class='fa fa-calendar-o'></i> Booking Slots</h4><hr>
		<?php
			$sql="SELECT * FROM book_slot inner join parking_area on book_slot.pid=parking_area.pid  where uid={$_SESSION["ID"]} group by bdate,slno order by bdate,slno";
			$res=$con->query($sql);
			if($res->num_rows>0)
			{
				echo "<table class='table table-bordered'>";
				echo "<tr>
					<th class='text-center'>SNo</th>
					<th class='text-center'>Booking Date</th>
					<th class='text-center'>Parking Area</th>
					<th class='text-center'>Slot No</th>
					<th class='text-center'>View and Update</th>
				</tr>";
				$i=0;
				while($row=$res->fetch_assoc())
				{
					$i++;
					echo "<tr>";
					$date=date("d-m-Y",strtotime($row["bdate"]));
						echo "<td class='text-center'>{$i}</td>";
						echo "<td class='text-center'>{$date}</td>";
						echo "<td><img src='{$row["PIMG"]}' style='height:75px; width:75px; float:left;'> <span style='padding:10px;float:left;'>{$row["PAREA"]}</span></td>";
						echo "<td class='text-center'>{$row["slno"]}</td>";
						echo "<td class='text-center'><a class='btn btn-sm btn-success' href='view_book.php?bid={$row["bid"]}&bdate={$row["bdate"]}&bname={$row["PAREA"]}&slno={$row["slno"]}'>View Details</a></td>";
					echo "</tr>";
				}
				echo "</table>";
			}
		?>
		</div>
	</div>
</div>
<?php include "footer.php";?>
<script src="jqueryui/jquery-ui.min.js"></script>
</body>
</html>	