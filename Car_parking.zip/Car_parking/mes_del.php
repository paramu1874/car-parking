<?php
	include "config.php";
	$sql="delete from message where mid='{$_POST["id"]}'";
	if($con->query($sql))
	{
		echo "Data Deleted.";
	}

?>
