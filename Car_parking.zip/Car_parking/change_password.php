<?php
session_start();
include"config.php";
if(!isset($_SESSION["AID"]))
{
	echo "<script>window.open('index.php','_self')</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<?php include"head.php";?>
</head>
<body>  
 
<div class="container-fluid">
	<div class="row">
	<?php include"navbar.php";?>
		<div class="col-md-3 box">
			<?php include "sidebar.php";?>
		</div>
		<div class="col-md-9 mbox">
			
			<div class="col-md-6 content">
				<h3 class="page-header">Welcome <?php echo $_SESSION["ANAME"];?></h3>
				<?php 
					if(isset($_POST["submit"]))
					{
						$sql="select * from admin where APASS='{$_POST["opass"]}' and AID='{$_SESSION["AID"]}'";
						$result=$con->query($sql);
							if($result->num_rows>0)
							{
								if($_POST["npass"]==$_POST["cpass"])
								{
									$sql="UPDATE admin SET  APASS='{$_POST["npass"]}' where  AID='{$_SESSION["AID"]}'";
									$con->query($sql);
									echo"<div class='alert alert-success'>password Changed</div>";
								}
								else
								{
									echo"<div class='alert alert-warning'>password Mismatch</div>";
								}
							}
							else
							{
								echo"<div class='alert alert-danger'>Invalid password</div>";
							}
					}
				?>
				<form action="<?php echo $_SERVER["PHP_SELF"];?>" role="form" method="post" >
					 <div class="form-group">
						 <label > Old Password : </label>
						 <input type="text"  name="opass"  required  class="form-control" placeholder="Old Password">
					</div>
					<div class="form-group">
						 <label > New Password : </label>
						 <input type="text"  name="npass"  required class="form-control" placeholder="New Password">
					</div>
					<div class="form-group">
						 <label > Confirm  Password : </label>
						 <input type="text"  name="cpass"  required class="form-control" placeholder="Confirm  Password">
					</div>
					<div class="form-group">
						
						<button type="submit" class="btn btn-success" id="submit" name="submit"> Save Details</button>
						<button type="reset" class="btn btn-danger" id="clear" name="clear"> Clear Details</button>
					</div>
				</form>
			</div>
			
			
			<?php include "footer.php";?>
		</div>
	</div>
</div>

</body>
</html>	