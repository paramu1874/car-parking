<?php
session_start();
include"config.php";
if(!isset($_SESSION["AID"]))
{
	echo "<script>window.open('index.php','_self')</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<?php include"head.php";?>
</head>
<body>  
 
<div class="container-fluid">
	<div class="row">
	<?php include"navbar.php";?>
		<div class="col-md-3 box">
			<?php include "sidebar.php";?>
		</div>
		<div class="col-md-9 mbox">
			
			<div class="col-md-12 content">
				<h3 class="page-header">Welcome <?php echo $_SESSION["ANAME"];?></h3>
				<div class="col-md-4">
					<div class="progress blue">
						<span class="progress-left">
							<span class="progress-bar"></span>
						</span>
						<span class="progress-right">
							<span class="progress-bar"></span>
						</span>
						<div class="progress-value">Booking</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="progress yellow">
						<span class="progress-left">
							<span class="progress-bar"></span>
						</span>
						<span class="progress-right">
							<span class="progress-bar"></span>
						</span>
						<div class="progress-value">Users</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="progress green">
						<span class="progress-left">
							<span class="progress-bar"></span>
						</span>
						<span class="progress-right">
							<span class="progress-bar"></span>
						</span>
						<div class="progress-value">Parking</div>
					</div>
				</div>
			</div>
			
			<?php include "footer.php";?>
		</div>
	</div>
</div>

</body>
</html>	