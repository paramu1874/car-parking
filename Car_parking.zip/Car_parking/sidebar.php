<style>
@media  screen and (max-width:600px)
{
	.box{
		display:none;
	}
}
</style>
<h3 class="page-header "><i class="glyphicon glyphicon-dashboard"></i> Dashboard</h3>
<ul class="nav list-group sidebox side">
	<li class="list-group-item"><a href="admin_home.php">  Home</a></li>
	<li class="list-group-item"><a href="parking_area.php">  Add Parking Area</a></li>
	<li class="list-group-item"><a href="admin_view_user.php">  View User</a></li>
	<li class="list-group-item"><a href="admin_view_mes.php">  View Message</a></li>
</ul>