<?php
	include "config.php";
	session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Car Parking</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/login.css" rel="stylesheet">
   
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>

	<nav class="navbar navbar-expand-md  bg-danger  navbar-dark">
	  <a class="navbar-brand" href="#">Car Parking Reservation</a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		<span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="collapsibleNavbar" >
		<ul class="navbar-nav " style="position:absolute;right:35px;">
		  <li class="nav-item">
			<a class="nav-link " href="#myModal" data-toggle="modal" style="color:white;">Admin</a>
		  </li>
		</ul>
	  </div>  
	</nav>

		<div class="login-reg-panel">
			<div class="login-info-box">
				<h2>Have an account?</h2>
				<p>Login Here...</p>
				<label id="label-register" for="log-reg-show">Login</label>
				<input type="radio" name="active-log-panel" id="log-reg-show"  checked="checked">
			</div>
								
			<div class="register-info-box">
				<h2>Don't have an account?</h2>
				<p>Register your Details..!</p>
				<label id="label-login" for="log-login-show">Register</label>
				<input type="radio" name="active-log-panel" id="log-login-show">
			</div>
								
			<div class="white-panel">
				<div class="login-show">
					<h2>LOGIN</h2>
						<?php
							if(isset($_POST["login"]))
							{
								$sql="SELECT * FROM user WHERE NAME='{$_POST["name"]}' AND PASS='{$_POST["pass"]}'";
								$res=$con->query($sql);
								if($res->num_rows>0)
								{
									$row=$res->fetch_assoc(); 
									$_SESSION["ID"]=$row["ID"];
									$_SESSION["NAME"]=$row["NAME"];
									echo "<script>window.open('user_home.php','_self')</script>";
								}
								else
								{
									echo"<div class='alert alert-danger'>Invalid User name Password<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a></div>";
								}
							}
						?>
					 <form action="<?php echo $_SERVER["REQUEST_URI"];?>" method="post">
						<input type="text" placeholder="User Name" name="name">
						<input type="password" placeholder="Password" name="pass">
						<input type="submit" value="Login" name="login">
					</form>
				</div>
				<div class="register-show">
					<h2>REGISTER</h2>
					<?php
						if(isset($_POST["reg"]))
						{
							$uname=$con->escape_string($_POST["uname"]);
							$email=$con->escape_string($_POST["email"]);
							$upass=$con->escape_string($_POST["upass"]);
						
						 $sql="INSERT INTO user(NAME, PASS, UMAIL) VALUES ('{$uname}','{$upass}','{$email}')";
									
							 if($con->query($sql))
							{
								echo "<script>alert('Insert Success');</script>";
							}
							else
							{
								echo "<div class='alert alert-danger'>Insert Failed</div>";
							}

						}							
					
					?>
					 <form action="<?php echo $_SERVER["REQUEST_URI"];?>" method="post">
						<input type="text" placeholder="User Name" name="uname">
						<input type="text" placeholder="Email" name="email">
						<input type="password" placeholder="Password" name="upass">
						
						<input type="submit" value="Register" name="reg">
					</form>
				</div>
			</div>
		</div>
	
<div class="modal fade" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Admin Login</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
			<?php
				if(isset($_POST["admin"]))
				{
					$sql="SELECT * FROM admin WHERE ANAME='{$_POST["aname"]}' AND APASS='{$_POST["apass"]}'";
					$res=$con->query($sql);
					if($res->num_rows>0)
					{
						$row=$res->fetch_assoc(); 
						$_SESSION["AID"]=$row["AID"];
						$_SESSION["ANAME"]=$row["ANAME"];
						echo "<script>window.open('admin_home.php','_self')</script>";
					}
					else
					{
						echo"<div class='alert alert-danger'>Invalid User name Password<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a></div>";
					}
				}
			?>
		 <form action="<?php echo $_SERVER["REQUEST_URI"];?>" method="post">
		  <div class="form-group">
			<label for="email">User Name:</label>
			<input type="text" class="form-control" id="name" name="aname">
		  </div>
		  <div class="form-group">
			<label for="pwd">Password:</label>
			<input type="password" class="form-control" id="pwd" name="apass">
		  </div>
		
		  <button type="submit" class="btn btn-primary" name="admin">Submit</button>
		</form> 
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
<script type="text/javascript">

    $(document).ready(function(){
    $('.login-info-box').fadeOut();
    $('.login-show').addClass('show-log-panel');
});


$('.login-reg-panel input[type="radio"]').on('change', function() {
    if($('#log-login-show').is(':checked')) {
        $('.register-info-box').fadeOut(); 
        $('.login-info-box').fadeIn();
        
        $('.white-panel').addClass('right-log');
        $('.register-show').addClass('show-log-panel');
        $('.login-show').removeClass('show-log-panel');
        
    }
    else if($('#log-reg-show').is(':checked')) {
        $('.register-info-box').fadeIn();
        $('.login-info-box').fadeOut();
        
        $('.white-panel').removeClass('right-log');
        
        $('.login-show').addClass('show-log-panel');
        $('.register-show').removeClass('show-log-panel');
    }
});
  

</script>
</body>
</html>
