    <nav class="navbar navbar-inverse shadow" role="navigation">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><i class="fa fa-car"></i> Car Parking</a>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
			
				
							<li><a href="user_home.php"> Home</a></li>
							<li><a href="view_area.php"> Parking Area</a></li>
							<li><a href="view_booking.php"> View Booking</a></li>
							<li><a href="cancel_booking.php"> Cancel Booking</a></li>
							<li><a href="send_message.php"> Send Feedback</a></li>
							<li><a href="change_pass.php"> Setting</a></li>
						
							<li><a href="logout.php"> Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>