<?php 
	include "config.php";
	session_start();
	echo $sql="delete from book_slot where bdate='{$_GET["bdate"]}' and slno='{$_GET["slno"]}' and 	uid='{$_SESSION["ID"]}'";
	if($con->query($sql))
	{
		header("location:cancel_booking.php");
	}
?>