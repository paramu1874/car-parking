<?php
	include "config.php";
	$sql="delete from parking_area where PID='{$_POST["id"]}'";
	if($con->query($sql))
	{
		echo "Data Deleted.";
	}

?>
